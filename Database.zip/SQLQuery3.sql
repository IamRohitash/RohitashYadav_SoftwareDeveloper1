Create or alter proc usp_getdatabyId_student
@id int


as
begin
     SELECT StudentDetails.First_Name, StudentDetails.Last_Name,StudentDetails.Class,
	 StudentMarks.Marks,StudentMarks.Subject_Id
     FROM StudentDetails join StudentMarks
     on StudentDetails.Id = @id  and StudentMarks.Student_Id=@id;
            
end

Create proc usp_create_student
@first_name varchar(50),
@last_name varchar(50),
@class varchar(10),
@subject_id int,
@marks varchar(10)

as
begin
     insert into StudentDetails values(@first_name,@last_name,@class)
     declare @id int
     select @id = scope_identity()
     insert into StudentMarks values(@marks,@subject_id,@id)         
end

Create proc usp_create_student
@first_name varchar(50),
@last_name varchar(50),
@class varchar(10),
@subject_id int,
@marks varchar(10)

as
begin
     insert into StudentDetails values(@first_name,@last_name,@class)
     declare @id int
     select @id = scope_identity()
     insert into StudentMarks values(@marks,@subject_id,@id)         
end

Create or alter proc usp_deletedatabyId_student
@id int
as
begin
     delete  
     from StudentDetails  
     where StudentDetails.Id = @id
	 delete  
     from StudentMarks  
     where StudentMarks.Student_Id = @id       
end

 
