insert into StudentSubjects values('Hindi'),('English'),('Math'),('Physics');
select * from StudentSubjects
select * from StudentDetails    
select * from StudentMarks

insert into StudentDetails values('Rohitash','Yadav','12th'),('Rahul','Yadav','9th'),('Mohit','Yadav','10th'),('Rohit','Yadav','11th');