select * from StudentSubjects
select * from StudentDetails
select * from StudentMarks

insert into StudentMarks values('80',13,9),('70',11,11)

 

WITH cte AS (
    SELECT 
        Id, 
        First_Name, 
        Last_Name, 
        Class, 
        ROW_NUMBER() OVER (
            PARTITION BY 
                First_Name, 
               Last_Name, 
               Class
            ORDER BY 
               First_Name, 
               Last_Name, 
               Class
        ) row_num
     FROM 
        StudentDetails
)
DELETE FROM cte
WHERE row_num > 1;
