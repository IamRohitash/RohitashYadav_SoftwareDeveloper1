﻿namespace CurdMachineTask.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class StudentMigration1 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.StudentDetails",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        First_Name = c.String(nullable: false),
                        Last_Name = c.String(nullable: false),
                        Class = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.StudentMarks",
                c => new
                    {
                        Marks_Id = c.Int(nullable: false, identity: true),
                        Subject_Name = c.String(nullable: false),
                        Marks = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Marks_Id);
            
            CreateTable(
                "dbo.StudentSubjects",
                c => new
                    {
                        Subject_Id = c.Int(nullable: false, identity: true),
                        Subject_Name = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Subject_Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.StudentSubjects");
            DropTable("dbo.StudentMarks");
            DropTable("dbo.StudentDetails");
        }
    }
}
