﻿namespace CurdMachineTask.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class StudentMigration6 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.StudentMarks", "Subject_Id", c => c.Int(nullable: false));
            AddColumn("dbo.StudentMarks", "Student_Id", c => c.Int(nullable: false));
            AlterColumn("dbo.StudentMarks", "Marks", c => c.String(nullable: false));
            DropColumn("dbo.StudentMarks", "Subject_Name");
        }
        
        public override void Down()
        {
            AddColumn("dbo.StudentMarks", "Subject_Name", c => c.String(nullable: false));
            AlterColumn("dbo.StudentMarks", "Marks", c => c.Int(nullable: false));
            DropColumn("dbo.StudentMarks", "Student_Id");
            DropColumn("dbo.StudentMarks", "Subject_Id");
        }
    }
}
