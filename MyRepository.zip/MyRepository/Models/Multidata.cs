﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CurdMachineTask.Models
{
    public class Multidata
    {
        public IEnumerable<StudentDetails> studentdetail { get; set; }
        public IEnumerable<StudentSubjects> studentSubject { get; set; }
        public IEnumerable<StudentMarks> studentMarks { get; set; }
    }
}