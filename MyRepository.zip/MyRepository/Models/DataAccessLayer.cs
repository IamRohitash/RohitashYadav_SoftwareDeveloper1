﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace CurdMachineTask.Models
{
    public class DataAccessLayer
    {
        public string InsertData(StudentScore studentScore)
        {
            SqlConnection con = null;

            string result = "";
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["StudentContext"].ToString());
                SqlCommand cmd = new SqlCommand("usp_create_student", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue("@CustomerID", 0);    
                cmd.Parameters.AddWithValue("@first_name", studentScore.FirstName);
                cmd.Parameters.AddWithValue("@last_name", studentScore.LastName);
                cmd.Parameters.AddWithValue("@class", studentScore.Class);
                cmd.Parameters.AddWithValue("@subject_Id", studentScore.StudentMarksListingRecords[0].Subject);
                cmd.Parameters.AddWithValue("@marks", studentScore.StudentMarksListingRecords[1].Marks);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch
            {
                return result = "";
            }
            finally
            {
                con.Close();
            }
        }
        public string UpdateData(StudentScore studentScore)
        {
            SqlConnection con = null;
            string result = "";
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["StudentContext"].ToString());
                SqlCommand cmd = new SqlCommand("usp_update_student", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", studentScore.Id);
                cmd.Parameters.AddWithValue("@first_name", studentScore.FirstName);
                cmd.Parameters.AddWithValue("@last_name", studentScore.LastName);
                cmd.Parameters.AddWithValue("@class", studentScore.Class);
                var sub_id = 0;
                if (studentScore.StudentMarksListingRecords[0].Subject == 11)
                {
                    sub_id = 11;
                }
                else if(studentScore.StudentMarksListingRecords[0].Subject == 12)
                {
                    sub_id = 12;
                }else if(studentScore.StudentMarksListingRecords[0].Subject == 13)
                {
                    sub_id = 13;
                }else if( studentScore.StudentMarksListingRecords[0].Subject == 14)
                {
                    sub_id= 14;
                }
                cmd.Parameters.AddWithValue("@subject_id", sub_id);
                cmd.Parameters.AddWithValue("@marks", studentScore.StudentMarksListingRecords[0].Marks);
                cmd.Parameters.AddWithValue("@marks_id", studentScore.StudentMarksListingRecords[0].MarksId);
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch
            {
                return result = "";
            }
            finally
            {
                con.Close();
            }
        }
        public string deleteStudentDataById(int? id)
        {
            SqlConnection con = null;
            string result = "";
            try
            {
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["StudentContext"].ToString());
                SqlCommand cmd = new SqlCommand("usp_deletedatabyId_student", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                
                con.Open();
                result = cmd.ExecuteScalar().ToString();
                return result;
            }
            catch
            {
                return result = "";
            }
            finally
            {
                con.Close();
            }
        }
    }
}