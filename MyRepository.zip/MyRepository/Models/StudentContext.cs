﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace CurdMachineTask.Models
{
    public class StudentContext : DbContext
    {
        public DbSet<StudentDetails> StudentDetail { get; set; }
        public DbSet<StudentSubjects> StudentSubjects { get; set; }
        public DbSet<StudentMarks> StudentMarks { get; set; }

        
    }
}