﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CurdMachineTask.Models
{
    public class StudentSubjects
    {
        [Key]
        public int Subject_Id { get; set; }
        public string Subject_Name { get; set; }

    }
}