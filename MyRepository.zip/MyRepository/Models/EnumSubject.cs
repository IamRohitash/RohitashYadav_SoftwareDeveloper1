﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CurdMachineTask.Models
{
    public enum EnumSubjects
    {

    Hindi=10,
    Engilish=11,
    Math=12,
    Physics=13
    }
}