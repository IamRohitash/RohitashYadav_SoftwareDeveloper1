﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CurdMachineTask.Models
{
    public class LogicLayer
    {
        private StudentContext db = new StudentContext();

        public List<StudentScore> GetAllStudentList()
        {
            var d = (from student in db.StudentDetail
                     join subjectMarks in db.StudentMarks on
                   student.Id equals subjectMarks.Student_Id
                     select new StudentMarksListingRecords1()
                     {
                         StudentId = subjectMarks.Student_Id,
                         Subject = subjectMarks.Subject_Id,
                         Marks = subjectMarks.Marks
                     }).AsEnumerable();
            var a = (from student in db.StudentDetail
                     join subjectMarks in db.StudentMarks on
                   student.Id equals subjectMarks.Student_Id
                     join studentsubject in db.StudentSubjects on
                     subjectMarks.Subject_Id equals studentsubject.Subject_Id
                     select new StudentScore
                     {
                         Id = student.Id,
                         FirstName = student.First_Name,
                         LastName = student.Last_Name,
                         Class = student.Class
                         ,
                         StudentMarksListingRecords = d.AsEnumerable().Where(x => x.StudentId == subjectMarks.Student_Id).ToList()
                     }).ToList();

            return a.ToList();
        }

        public IList<StudentScore> CreateStudentDetail(StudentDetails studentdetail)
        {
            var data = new List<StudentScore>();
            return data;
        }

        public List<StudentScore> getSearchStudent(string search)
        {
            var d = (from student in db.StudentDetail
                     join subjectMarks in db.StudentMarks on
                   student.Id equals subjectMarks.Student_Id
                     select new StudentMarksListingRecords1()
                     {
                         StudentId = subjectMarks.Student_Id,
                         Subject = subjectMarks.Subject_Id,
                         Marks = subjectMarks.Marks
                     }).AsEnumerable();
            var c = (from student in db.StudentDetail
                     join subjectMarks in db.StudentMarks on
                   student.Id equals subjectMarks.Student_Id
                     join studentsubject in db.StudentSubjects on
                     subjectMarks.Subject_Id equals studentsubject.Subject_Id
                     select new StudentScore
                     {
                         Id = student.Id,
                         FirstName = student.First_Name,
                         LastName = student.Last_Name,
                         Class = student.Class
                         ,
                         StudentMarksListingRecords = d.AsEnumerable().Where(x => x.StudentId == subjectMarks.Student_Id).ToList()
                     }).Where(x => x.FirstName.StartsWith(search) || search == null).ToList();

            return c.ToList();
        }
    }
}