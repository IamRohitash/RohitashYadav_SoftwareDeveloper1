﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CurdMachineTask.Models
{
    public class StudentScore
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Required First Name.")]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Required Last Name.")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Required Class.")]
        [Display(Name = "Class")]
        public string Class { get; set; }

        public List<StudentMarksListingRecords1> StudentMarksListingRecords { get; set; }

    }
}