﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CurdMachineTask.Models
{
    public class StudentMarksListingRecords1
    {
        [Key]
        public int MarksId { get; set; }
        public int StudentId { get; set; }
        public int Subject { get; set; }
        public string Marks { get; set; }
    }
}