﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CurdMachineTask.Models
{
    public class StudentMarks
    {
        [Key]
        public int Marks_Id { get; set; }
        public int Subject_Id { get; set; }
        public int Student_Id { get; set; }
        [Required(ErrorMessage = "Required Subject Marks.")]
        [Display(Name = "Marks")]
        public string Marks { get; set; }
    }
}