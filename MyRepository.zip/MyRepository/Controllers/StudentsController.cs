﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CurdMachineTask.Models;
using PagedList;
using PagedList.Mvc;

namespace CurdMachineTask.Controllers
{
    public class StudentsController : Controller
    {
        private StudentContext db = new StudentContext();
        private LogicLayer ll = new LogicLayer();

        // GET: Students
        public ActionResult Studentlist(string search)
        {
            LogicLayer ll = new LogicLayer();
            List<StudentSubjects> subList = db.StudentSubjects.ToList();
            ViewBag.ClassNsub = new SelectList(subList, "Subject_Id", "Subject_Name");

            var Alldetail = ll.getSearchStudent(search).ToList();
            var Unqdetail = Alldetail.GroupBy(x => x.Id).Select(y => y.First()).Distinct().ToList();
           
            
            ViewBag.g = Unqdetail;
            
            return View();
        }
        [HttpPost]
        public ActionResult Studentlist(int ClassNsub)
        {
            LogicLayer ll = new LogicLayer();
            List<StudentSubjects> subList = db.StudentSubjects.ToList();
            ViewBag.ClassNsub = new SelectList(subList, "Subject_Id", "Subject_Name");

            var Alldetail = ll.GetAllStudentList().Where(x => x.Id == ClassNsub || x.StudentMarksListingRecords[0].Subject==ClassNsub);
            var Unqdetail = Alldetail.GroupBy(x => x.Id).Select(y => y.First()).Distinct().ToList();


            ViewBag.g = Unqdetail;

            return RedirectToAction("Studentlist");
        }

        // GET: Students/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StudentDetails studentDetails = db.StudentDetail.Find(id);
            if (studentDetails == null)
            {
                return HttpNotFound();
            }
            return View(studentDetails);
        }

        // GET: Students/Create
        public ActionResult Create()
        {
            List<StudentSubjects> subList = db.StudentSubjects.ToList();
            ViewBag.data = new SelectList(subList, "Subject_Id", "Subject_Name");
            return View();
        }

        // POST: Students/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(StudentScore studentScore)
        {
            if (ModelState.IsValid) //checking model is valid or not    
            {
                DataAccessLayer objDB = new DataAccessLayer();
                string result = objDB.InsertData(studentScore);
                //ViewData["result"] = result;    
                TempData["result1"] = result;
                ModelState.Clear(); //clearing model    
                                    //return View();    
                return RedirectToAction("Studentlist");
            }

            else
            {
                ModelState.AddModelError("", "Error in saving data");
                return View();
            }

           
        }

        // GET: Students/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            
            
            StudentScore _student = ll.GetAllStudentList().Where(c => c.Id == id).SingleOrDefault();
            List<StudentSubjects> subList = db.StudentSubjects.ToList();
            ViewBag.data = new SelectList(subList, "Subject_Id", "Subject_Name");

            //DataAccessLayer objDB = new DataAccessLayer();
            //var result = objDB.GetStudentDataById(id);
            /*var IdData=Unqdetail.Where(x=>x.Id == id).ToList();
            ViewBag.data = IdData;*/

            if (_student == null)
            {
                return HttpNotFound();
            }
            return View(_student);
        }

        // POST: Students/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(StudentScore studentScore)
        {
            if (ModelState.IsValid) //checking model is valid or not    
            {
                DataAccessLayer objDB = new DataAccessLayer();
                string result = objDB.UpdateData(studentScore);
                //ViewData["result"] = result;    
                TempData["result1"] = result;
                ModelState.Clear(); //clearing model    
                                    //return View();    
                return RedirectToAction("Studentlist");
            }

            else
            {
                ModelState.AddModelError("", "Error in saving data");
                return View();
            }
        }

        // GET: Students/Delete/5
        public ActionResult Delete(int? id)
        {
            LogicLayer ll = new LogicLayer();

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            StudentScore _student = ll.GetAllStudentList().Where(c => c.Id == id).SingleOrDefault();
            if (_student.StudentMarksListingRecords[0].Subject == 10) {
                ViewBag.sub = "Hindi";
            }
            else if (_student.StudentMarksListingRecords[0].Subject == 11)
            {
                ViewBag.sub = "English";
            }
            else if (_student.StudentMarksListingRecords[0].Subject == 12)
            {
                ViewBag.sub = "Math";
            }
            else if (_student.StudentMarksListingRecords[0].Subject == 13)
            {
                ViewBag.sub = "Physics";
            }

            if (_student == null)
                {
                    return HttpNotFound();
                }
            
            return View(_student);
        }

        // POST: Students/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            DataAccessLayer objDB = new DataAccessLayer();
            string result = objDB.deleteStudentDataById(id);
            //ViewData["result"] = result;    
            TempData["result1"] = result;
            ModelState.Clear(); //clearing model    
                                //return View();    
            return RedirectToAction("Studentlist");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
